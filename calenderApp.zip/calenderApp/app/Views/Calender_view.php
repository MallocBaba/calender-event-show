<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Google Calendar API Quickstart</title>
    <script src="https://code.jquery.com/jquery-3.6.4.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <h2 class="text-center mt-5">Google Calendar API Quickstart</h2>

        <!-- Authorization and Sign-out buttons -->
        <div class="row mt-5 justify-content-centre">
            <div class="col-md-2">
                <button id="authorize_button" class="btn btn-primary" onclick="handleAuthClick()">Authorize</button>
            </div>
            <div class="col-md-2">
                <button id="signout_button" class="btn btn-danger" onclick="handleSignoutClick()" style="display: none;">Sign Out</button>
            </div>
        </div>

        <pre id="content" class="mt-5 text-center" style="white-space: pre-wrap;"></pre>
    </div>

    <script type="text/javascript">
        // TODO: Replace with your Client ID and API Key from the Google Developer Console
        const CLIENT_ID = '765829815869-emefiq1g2sqn05eudeeq0bec9qvdkqjv.apps.googleusercontent.com';
        const API_KEY = 'AIzaSyBa1st3o9v-eBaK2GIs8OUykrjPhEyUXr4';

        // Discovery document URL
        const DISCOVERY_DOC = 'https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest';

        // Authorization scopes required by the API
        const SCOPES = 'https://www.googleapis.com/auth/calendar.readonly';

        let tokenClient;
        let gapiInited = false;
        let gisInited = false;

        /**
         * Callback after api.js is loaded.
         */
        function gapiLoaded() {
            gapi.load('client', initializeGapiClient);
        }

        /**
         * Callback after the API client is loaded.
         */
        async function initializeGapiClient() {
            await gapi.client.init({
                apiKey: API_KEY,
                discoveryDocs: [DISCOVERY_DOC],
            });
            gapiInited = true;
            maybeEnableButtons();
        }

        /**
         * Callback after Google Identity Services are loaded.
         */
        function gisLoaded() {
            tokenClient = google.accounts.oauth2.initTokenClient({
                client_id: CLIENT_ID,
                scope: SCOPES,
                callback: '', // Defined later
            });
            gisInited = true;
            maybeEnableButtons();
        }

        /**
         * Enables user interaction after all libraries are loaded.
         */
        function maybeEnableButtons() {
            if (gapiInited && gisInited) {
                document.getElementById('authorize_button').style.visibility = 'visible';
            }
        }

        /**
         * Sign in the user upon button click.
         */
        function handleAuthClick() {
            tokenClient.callback = async (resp) => {
                if (resp.error !== undefined) {
                    console.error("Error during authentication:", resp.error);
                    return;
                }
                document.getElementById('signout_button').style.display = 'block';
                document.getElementById('authorize_button').innerText = 'Refresh';
                await listUpcomingEvents();
            };

            if (gapi.client.getToken() === null) {
                tokenClient.requestAccessToken({ prompt: 'consent' });
            } else {
                tokenClient.requestAccessToken({ prompt: '' });
            }
        }

        /**
         * Sign out the user upon button click.
         */
        function handleSignoutClick() {
            const token = gapi.client.getToken();
            if (token !== null) {
                google.accounts.oauth2.revoke(token.access_token);
                gapi.client.setToken(null);
                document.getElementById('content').innerText = '';
                document.getElementById('authorize_button').innerText = 'Authorize';
                document.getElementById('signout_button').style.display = 'none';
            }
        }

        /**
         * Fetch and display upcoming calendar events.
         */
        async function listUpcomingEvents() {
            try {
                const request = {
                    'calendarId': 'primary',
                    'timeMin': (new Date()).toISOString(),
                    'showDeleted': false,
                    'singleEvents': true,
                    'maxResults': 10,
                    'orderBy': 'startTime',
                };

                const response = await gapi.client.calendar.events.list(request);

                console.log("API Response:", response); // Debugging: Check response structure

                // Ensure response contains expected data
                if (!response || !response.result || !response.result.items) {
                    document.getElementById('content').innerText = 'No events found.';
                    return;
                }

                // Extract events
                const events = response.result.items;
                if (events.length === 0) {
                    document.getElementById('content').innerText = 'No events found.';
                    return;
                }

                // Format and display events
                const output = events.map(event => {
                    let start = event.start?.dateTime || event.start?.date || "Unknown date";
                    return `${event.summary || "No Title"} (${start})`;
                }).join("\n");

                document.getElementById('content').innerText = `Events:\n${output}`;
            } catch (err) {
                console.error("Error fetching events:", err);
                document.getElementById('content').innerText = `Error: ${err.message}`;
            }
        }
    </script>

    <!-- Load Google APIs -->
    <script async defer src="https://apis.google.com/js/api.js" onload="gapiLoaded()"></script>
    <script async defer src="https://accounts.google.com/gsi/client" onload="gisLoaded()"></script>

</body>

</html>