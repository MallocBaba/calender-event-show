<?php

namespace App\Config;

class Google
{
    public static $clientId = 'YOUR_GOOGLE_CLIENT_ID';
    public static $clientSecret = 'YOUR_GOOGLE_CLIENT_SECRET';
    public static $redirectUri = 'http://localhost:8080/google/callback';
    public static $scopes = ['https://www.googleapis.com/auth/calendar.readonly'];
}
